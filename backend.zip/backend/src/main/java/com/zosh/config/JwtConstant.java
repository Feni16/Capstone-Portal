package com.zosh.config;

public class JwtConstant {
	
	public static final String SECRET_KEY= "jdfjakjehnhrio8uw8ejrbdjhhfuigejrhsgh";
	public static final String JWT_HEADER="Authorization";

}
