package com.zosh.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zosh.model.User;

import aj.org.objectweb.asm.Label;

//public interface LabelRepository extends JpaRepository<Label, Long> {
//    Optional<Label> findByName(String name);
//    List<Label> findByCreator(User creator);
//}
