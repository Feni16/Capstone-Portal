package com.zosh.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    // Existing fields...

    @ManyToOne
    @JoinColumn(name = "guide_id")
    private Faculty guide;
}
