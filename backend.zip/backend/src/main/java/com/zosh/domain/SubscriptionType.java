package com.zosh.domain;

public enum SubscriptionType {
    FREE,
    PAID
}
