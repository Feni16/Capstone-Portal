package com.zosh.domain;

public enum PlanType {
    MONTHLY,
    ANNUALLY,
    FREE
}
