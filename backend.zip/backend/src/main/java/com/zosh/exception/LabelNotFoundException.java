package com.zosh.exception;

public class LabelNotFoundException extends Exception {

	public LabelNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
