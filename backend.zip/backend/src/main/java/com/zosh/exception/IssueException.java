package com.zosh.exception;

public class IssueException extends Exception {

	public IssueException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
