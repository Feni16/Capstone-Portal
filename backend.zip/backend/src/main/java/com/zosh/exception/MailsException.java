package com.zosh.exception;

public class MailsException extends Exception{

	public MailsException(String message) {
		super(message);
		
	}
  
}
